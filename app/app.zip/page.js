import Checkout from "./checkout/page";

export default function Home() {
  return (
    <main>
      <Checkout />
    </main>
  );
}
